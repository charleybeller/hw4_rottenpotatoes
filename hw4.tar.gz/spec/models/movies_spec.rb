require 'spec_helper'

describe Movies do
  describe ':find_similar method' do
    it 'should take a movie object'
    it 'should return all movies with the same director attribute as the original movie'
end
